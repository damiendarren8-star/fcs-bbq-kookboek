# FCS BBQ App Final

Upload deze bestanden naar je GitHub Pages repo:

- index.html
- manifest.webmanifest
- service-worker.js
- icon-192.png
- icon-512.png

## GitHub Pages
1. Open je GitHub repo: fcs-bbq-kookboek
2. Upload/vervang alle bestanden in de root.
3. Zorg dat het hoofdbestand `index.html` heet.
4. Wacht 1-3 minuten.
5. Open je GitHub Pages link.

## iPhone als app installeren
1. Open de GitHub Pages link in Safari.
2. Tik op delen.
3. Kies “Zet op beginscherm”.
4. Naam: FCS BBQ.
5. Tik Voeg toe.
